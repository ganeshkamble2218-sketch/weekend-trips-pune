// Reusable 19-seat system.
// Put this same component/logic on every trip page.
// Change only the trip name and bookedSeats for each trip.

const tripConfig = {
  tripName: new URLSearchParams(location.search).get("trip") || "Kaas Pathar",
  bookedSeats: [] // Example: [2, 7, 15]
};

document.getElementById("tripName").textContent = tripConfig.tripName;

const grid = document.getElementById("seatGrid");
const selectedSeatEl = document.getElementById("selectedSeat");
const continueBtn = document.getElementById("continueBtn");

let selectedSeat = null;

for (let seatNo = 1; seatNo <= 19; seatNo++) {
  const btn = document.createElement("button");
  btn.className = "seat";
  btn.textContent = seatNo;
  btn.type = "button";

  if (tripConfig.bookedSeats.includes(seatNo)) {
    btn.classList.add("booked");
    btn.disabled = true;
  }

  btn.addEventListener("click", () => {
    if (btn.classList.contains("booked")) return;

    document.querySelectorAll(".seat.selected").forEach(s => s.classList.remove("selected"));
    btn.classList.add("selected");
    selectedSeat = seatNo;
    selectedSeatEl.textContent = `Seat ${seatNo}`;
    continueBtn.disabled = false;
  });

  grid.appendChild(btn);
}

continueBtn.addEventListener("click", () => {
  const trip = encodeURIComponent(tripConfig.tripName);
  alert(`Trip: ${tripConfig.tripName}\nSeat: ${selectedSeat}\n\nConnect this button to your existing passenger/payment page.`);
});
